 How to install and build your system:
 - First of all, you need to have OCaml installed!
 - Download the source code to play on your computer.
 - On your command shell, navigate to the folder where the software is installed.
 - Input "make build" to install the essential codes
 - Input "make play" to start playing!
 - Follow instructions prompted by the game and enjoy!