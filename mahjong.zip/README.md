# final_project
mahjong game in OCaml. Run in command line shell.
