let current_loc : int = 2377
